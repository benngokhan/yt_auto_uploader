"""Reusable accepted-071 contract. Pure validation; no inference, publication or I/O."""
from __future__ import annotations
import hashlib,json,math,re,unicodedata
from urllib.parse import urlsplit

PROFILE='accepted071-five-visuals-v2'
SLOGAN='Merakını besle, Bilgi Dozu’nu takip et!'
COMMENT='Cevabını yoruma yaz!'
IMAGE_MODEL='@cf/black-forest-labs/flux-2-klein-4b'
TTS_MODEL='gemini-2.5-flash-preview-tts'
VOICE='Charon'

class ContractError(ValueError):pass

def canonical(text):
 return ''.join(c for c in unicodedata.normalize('NFKD',str(text).casefold().replace('ı','i')) if c.isalnum() and not unicodedata.combining(c))

def digest_json(obj):
 return hashlib.sha256(json.dumps(obj,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()

def line(value,name,limit=500):
 if not isinstance(value,str) or not value.strip() or '\n' in value or len(value)>limit:
  raise ContractError(name+' must be one nonempty bounded line')
 return ' '.join(value.split())

def finite(value,name):
 if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):raise ContractError(name+' must be finite numeric')
 return float(value)

def validate_plan(plan):
 if isinstance(plan,dict) and plan.get('profile')=='cinematic30-v1':
  from cinematic30_contract import validate_plan as cinematic_plan
  return cinematic_plan(plan)
 if not isinstance(plan,dict) or plan.get('profile')!=PROFILE:raise ContractError('wrong production profile')
 opening=line(plan.get('opening_question'),'opening_question',150)
 if not opening.endswith('?') or opening.count('?')!=1:raise ContractError('one opening question required')
 if any(x in canonical(opening) for x in ['takipet','yorumayaz']):raise ContractError('CTA cannot precede slogan')
 facts=plan.get('explanations')
 if not isinstance(facts,list) or len(facts)!=3:raise ContractError('exactly three explanatory beats required')
 facts=[line(x,'explanation',260) for x in facts]
 if any('?' in x or 'takipet' in canonical(x) or 'yorumayaz' in canonical(x) for x in facts):raise ContractError('explanations must not reorder or duplicate CTAs')
 if len(set(map(canonical,facts)))!=3:raise ContractError('repeated explanatory beat')
 source=plan.get('source') or {}
 u=urlsplit(str(source.get('url','')))
 if u.scheme!='https' or not u.hostname or u.username or u.password:raise ContractError('HTTPS scientific source required')
 label=line(source.get('label'),'source label',72)
 if source.get('reviewed') is not True or not line(source.get('review_note'),'source review',500):raise ContractError('source review required, URL alone is not evidence')
 visuals=plan.get('visuals')
 if not isinstance(visuals,list) or len(visuals)!=5:raise ContractError('five unique visuals required')
 for i,v in enumerate(visuals):
  if not isinstance(v,dict):raise ContractError('visual must be object')
  line(v.get('prompt'),'visual prompt',5000)
  line(v.get('mechanism'),'visual mechanism',400)
  if isinstance(v.get('seed'),bool) or not isinstance(v.get('seed'),int) or not 0<=v['seed']<=2147483647:raise ContractError('invalid visual seed')
  if v.get('representation') not in ('natural_scale','schematic'):raise ContractError('visual representation must be declared')
  checks=v.get('critical_checks')
  if not isinstance(checks,list) or not checks or any(not isinstance(x,str) or not x.strip() for x in checks):raise ContractError('scene-specific visual checks required')
 heads=plan.get('headlines')
 if not isinstance(heads,list) or len(heads)!=5:raise ContractError('five template headline beats required')
 for h in heads:
  if not isinstance(h,dict) or h.get('icon') not in ('?','!','▼','▲','⚡','✔'):raise ContractError('unknown semantic icon')
  for key in ['line1','line2']:line(h.get(key),'headline',32)
 if isinstance(plan.get('voice_speed_factor',1.0),bool) or plan.get('voice_speed_factor',1.0)!=1.0:raise ContractError('speedup forbidden')
 lines=[opening,SLOGAN,*facts,opening+' '+COMMENT]
 narration='\n'.join(lines)
 if len(narration)>650:raise ContractError('narration too long; rewrite, never accelerate')
 return {'profile':PROFILE,'script_lines':lines,'narration':narration,'source_label':label,'plan_sha256':digest_json(plan)}

def validate_alignment(plan,alignment,audio_sha,duration):
 script=validate_plan(plan);duration=finite(duration,'duration')
 if not 15<=duration<=25:raise ContractError('voice must naturally fit 15–25s; no tempo rescue')
 if not isinstance(alignment,dict) or alignment.get('audio_sha256')!=audio_sha:raise ContractError('alignment is not bound to this voice')
 if alignment.get('method') not in ('audio_grounded','human_verified'):raise ContractError('weighted/estimated subtitle alignment forbidden for new productions')
 expected=script['narration'].split();words=alignment.get('words')
 if not isinstance(words,list) or len(words)!=len(expected):raise ContractError('missing words, including comment CTA')
 previous=0.0
 for text,w in zip(expected,words):
  if not isinstance(w,dict) or canonical(w.get('word',''))!=canonical(text):raise ContractError('spoken/subtitle word mismatch')
  a=finite(w.get('start'),'word start');b=finite(w.get('end'),'word end')
  if a<previous-0.025 or not 0<=a<b<=duration:raise ContractError('bad audio-grounded timing')
  previous=b
 if words[0]['start']>0.35:raise ContractError('opening hook starts late')
 groups=[];pos=0
 for text in script['script_lines']:
  n=len(text.split());groups.append(words[pos:pos+n]);pos+=n
 slogan=groups[1];idx=next(i for i,w in enumerate(slogan) if canonical(w['word'])=='takip')
 click=float(slogan[idx]['start'])
 # Preserve all natural audio. Only visual boundaries fall in the measured gaps.
 edges=[0.0]+[(float(groups[i][-1]['end'])+float(groups[i+1][0]['start']))/2 for i in (1,2,3,4)]+[duration]
 if any(not 2<=b-a<=8 for a,b in zip(edges,edges[1:])):raise ContractError('natural narration does not fit five visual beats; rewrite rather than squeeze')
 cta={'start':float(slogan[0]['start']),'end':min(edges[1],float(slogan[-1]['end'])+0.18),'click':click}
 if not 0<=cta['start']<=click<cta['end']<=duration:raise ContractError('invalid CTA interval')
 return {'groups':groups,'edges':edges,'cta':cta,'script':script}

def validate_reviews(plan,rows,actual_hashes):
 if not isinstance(rows,list) or len(rows)!=5 or len(actual_hashes)!=5:raise ContractError('five reviewed images required')
 if len(set(actual_hashes))!=5:raise ContractError('repeated visual forbidden')
 for i,(row,digest) in enumerate(zip(rows,actual_hashes)):
  visual=plan['visuals'][i]
  if not isinstance(row,dict) or row.get('scene')!=i+1 or row.get('sha256')!=digest:raise ContractError('visual review hash/order mismatch')
  if row.get('approved') is not True or row.get('scientific_fit') is not True:raise ContractError('visual rejected or unreviewed')
  if row.get('representation')!=visual['representation']:raise ContractError('representation review mismatch')
  if row.get('checked_criteria')!=visual['critical_checks']:raise ContractError('scene-specific review criteria not checked')
  if row.get('distinct_from_other_scenes') is not True:raise ContractError('visual distinctness review required')
  line(row.get('reviewer'),'reviewer',100);line(row.get('note'),'review note',800)
 return True
