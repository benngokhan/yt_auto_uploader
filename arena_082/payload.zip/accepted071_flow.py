"""Opt-in production route integrated into motor/uret.py.

Generation and reviewed rendering are separate commands; rendering can never
call a provider. Outputs are local and cannot enqueue/publish. No legacy fallback.
"""
from __future__ import annotations
import hashlib,json,os,shutil,subprocess,sys,wave
from pathlib import Path
from accepted071_contract import *
from accepted071_providers import OnceBudget,Providers

HERE=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def readjson(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def save(path,obj):Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def local(root,name):
 if not isinstance(name,str) or Path(name).is_absolute():raise ContractError('relative job file required')
 target=(Path(root)/name).resolve()
 if not target.is_relative_to(Path(root).resolve()) or not target.is_file():raise ContractError('missing/outside job file')
 return target

def generate(plan,permit,work,state_root,provider_factory=Providers):
 check=validate_plan(plan)
 # Fail all credential checks before consuming an authorization or making any request.
 if provider_factory is Providers and any(not os.environ.get(k,'').strip() for k in ['GEMINI_API_KEY','CLOUDFLARE_ACCOUNT_ID','CLOUDFLARE_API_TOKEN']):raise ContractError('all provider credentials required before any call')
 work=Path(work);work.mkdir(parents=True,exist_ok=False)
 save(work/'plan.json',plan)
 budget=OnceBudget(permit,plan,state_root);api=provider_factory(budget)
 status={'profile':check['profile'],'plan_sha256':check['plan_sha256'],'generation_complete':False,'state':'reserved','images':[],'tts':None,'publication':False,'enqueue':False}
 save(work/'generation.json',status)
 try:
  status['tts']=api.tts(check['narration'],work/'voice.wav');save(work/'generation.json',status)
  for i,visual in enumerate(plan['visuals'],1):
   result=api.image(visual,work/f's{i}.jpg');status['images'].append(dict(result,scene=i,file=f's{i}.jpg'));save(work/'generation.json',status)
  status.update(generation_complete=True,state='awaiting_alignment_and_visual_review');save(work/'generation.json',status)
 except Exception:
  status.update(state='stopped_no_retry',attempts=budget.count);save(work/'generation.json',status);raise
 return status

def preflight_job(work):
 work=Path(work).resolve();plan=readjson(work/'plan.json');check=validate_plan(plan)
 status=readjson(work/'generation.json')
 if status.get('plan_sha256')!=check['plan_sha256'] or status.get('generation_complete') is not True:raise ContractError('incomplete/stale generation')
 voice=local(work,'voice.wav');voice_hash=sha(voice)
 tts=status.get('tts') or {}
 if tts.get('audio_sha256')!=voice_hash or tts.get('narration_sha256')!=hashlib.sha256(check['narration'].encode()).hexdigest():raise ContractError('voice does not contain this exact script, including comment CTA')
 if tts.get('model')!=TTS_MODEL or tts.get('voice')!=VOICE or tts.get('speed_factor')!=1.0:raise ContractError('wrong voice or processing')
 with wave.open(str(voice),'rb') as w:
  if (w.getnchannels(),w.getsampwidth(),w.getframerate(),w.getcomptype())!=(1,2,24000,'NONE'):raise ContractError('unmodified 24k mono PCM16 voice required')
  duration=w.getnframes()/w.getframerate()
 aligned=validate_alignment(plan,readjson(work/'alignment.json'),voice_hash,duration)
 rows=status.get('images')
 if not isinstance(rows,list) or len(rows)!=5:raise ContractError('five original images missing')
 hashes=[];pixel_hashes=[]
 from PIL import Image
 for i,row in enumerate(rows,1):
  if row.get('scene')!=i or row.get('file')!=f's{i}.jpg' or row.get('model')!=IMAGE_MODEL:raise ContractError('wrong image ordering/provider model')
  p=local(work,row['file']);digest=sha(p)
  if digest!=row.get('sha256'):raise ContractError('original image hash mismatch')
  with Image.open(p) as im:
   im.load()
   if im.size!=(720,1280):raise ContractError('wrong image dimensions')
   pixel_hashes.append(hashlib.sha256(im.convert('RGB').tobytes()).hexdigest())
  hashes.append(digest)
 if len(set(pixel_hashes))!=5:raise ContractError('decoded duplicate visual forbidden')
 validate_reviews(plan,readjson(work/'visual_reviews.json'),hashes)
 return plan,status,aligned

def align_local(work,model_path):
 work=Path(work).resolve();plan=readjson(work/'plan.json');check=validate_plan(plan)
 model=Path(model_path).resolve()
 if not model.is_dir() or not (model/'model.bin').is_file():raise ContractError('preinstalled local faster-whisper model directory required; no download')
 # Existing actual motor alignment implementation, never character-weighted timing.
 from karaoke_timing import KaraokeAligner
 target=work/'alignment.json'
 if target.exists():raise ContractError('alignment exists; do not silently replace')
 result=KaraokeAligner(str(model),local_files_only=True).align(work/'voice.wav',[check['narration']])
 result['engine_method']=result.get('method');result['method']='audio_grounded'
 save(target,result)
 return result

def render_reviewed(work,sfx,runner=subprocess.run):
 work=Path(work).resolve();plan,status,aligned=preflight_job(work)
 sfx=Path(sfx).resolve()
 if not sfx.is_file() or sha(sfx)!='2ac05408f311e6cdc458ae6b01209a367fcaf1190caf39a6e39bfa8705868850':raise ContractError('accepted click/diling source missing/changed')
 # Each render has isolated inputs; never delete son, candle assets or schedules.
 output=work/'render_accepted071'
 output.mkdir(exist_ok=False)
 for name in ['voice.wav','s1.jpg','s2.jpg','s3.jpg','s4.jpg','s5.jpg']:shutil.copyfile(local(work,name),output/name)
 shutil.copyfile(sfx,output/'click_diling.wav')
 export={'plan':plan,'aligned':aligned,'voice_sha256':status['tts']['audio_sha256'],'publication':False,'enqueue':False}
 save(output/'export.json',export)
 env=os.environ.copy();env.update(MIRA_MOTOR_W='720',MIRA_MOTOR_H='1280',MIRA_MOTOR_FPS='30',MIRA_DISABLE_WHISPER='1')
 runner([sys.executable,str(HERE/'accepted071/run.py'),str(output)],check=True,env=env)
 final=output/'video.mp4'
 if not final.is_file() or final.stat().st_size==0:raise ContractError('renderer did not produce video')
 ffmpeg=shutil.which('ffmpeg')
 if not ffmpeg:
  import imageio_ffmpeg
  ffmpeg=imageio_ffmpeg.get_ffmpeg_exe()
 decoded=runner([ffmpeg,'-v','error','-i',str(final),'-f','null','-'],check=True,capture_output=True,text=True,timeout=180)
 if decoded.stderr.strip():raise ContractError('MP4 decoder reported errors; no delivery approval')
 save(output/'delivery.json',{'profile':PROFILE,'mp4_sha256':sha(final),'script_sha256':digest_json(aligned['script']['script_lines']),'visual_checks':'hash-bound human review','full_mp4_decode':'passed','audio_listening_review':'pending','publication':False,'enqueue':False})
 return final

def run_from_args(args,settings):
 if getattr(args,'onay_verildi',False):raise ContractError('accepted071 release is local-only; publication/queue not enabled')
 if getattr(args,'sadece_ses',False):raise ContractError('voice-only is not supported in this profile; no image call made')
 modes=[bool(getattr(args,'plan_only',False)),bool(args.accepted_generate),bool(args.accepted_align_model),bool(args.accepted_validate_only)]
 if sum(modes)>1:raise ContractError('choose only one mode; no implicit generation')
 job=Path(args.accepted_job).resolve() if args.accepted_job else None
 if getattr(args,'plan_only',False):
  if not args.accepted_plan:raise ContractError('--accepted-plan required; this route never invokes the old seven-scene LLM')
  p=readjson(args.accepted_plan);result=validate_plan(p)
  print(json.dumps(result,ensure_ascii=False,indent=2));return 0
 if not job:raise ContractError('--accepted-job required')
 if args.accepted_generate:
  if not args.accepted_plan or not args.accepted_permit:raise ContractError('reviewed plan + new bounded permit required before generation')
  p=readjson(args.accepted_plan)
  if canonical(p.get('opening_question',''))!=canonical(args.konu):raise ContractError('plan/topic mismatch')
  result=generate(p,readjson(args.accepted_permit),job,HERE/'cikti/accepted071_authorizations')
  print('Generated locally; alignment and visual review required before render:',job);return 0
 if canonical(readjson(job/'plan.json').get('opening_question',''))!=canonical(args.konu):raise ContractError('job/topic mismatch')
 if args.accepted_align_model:
  align_local(job,args.accepted_align_model);print('Local alignment complete; no network call');return 0
 if args.accepted_validate_only:
  preflight_job(job);print('accepted071 preflight passed; no render/API/publication');return 0
 print('Local preview:',render_reviewed(job,HERE/'accepted071/assets/click_diling.wav'))
 return 0
