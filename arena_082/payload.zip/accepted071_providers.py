"""Bounded API adapters for accepted071. Importing never contacts a provider.

Each explicitly authorized operation is reserved on disk BEFORE the sole POST.
No retries, alternate model/provider, automatic paid upgrade, or publication.
"""
from __future__ import annotations
import base64,hashlib,io,json,os,re,urllib.request,uuid,wave
from pathlib import Path
from PIL import Image
from accepted071_contract import ContractError,PROFILE,IMAGE_MODEL,TTS_MODEL,VOICE,digest_json,validate_plan

class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**kw):return None

class OnceBudget:
 def __init__(self,permit,plan,state_root):
  validate_plan(plan)
  if not isinstance(permit,dict) or permit.get('profile')!=plan['profile'] or plan['profile'] not in (PROFILE,'cinematic30-v1') or permit.get('plan_sha256')!=digest_json(plan):raise ContractError('authorization is not for this plan')
  if permit.get('user_approved') is not True or not isinstance(permit.get('approval_note'),str) or not permit['approval_note'].strip():raise ContractError('new explicit user authorization required')
  if permit.get('limits')!={'tts':1,'images':5} or any(type(v) is not int for v in permit.get('limits',{}).values()) or permit.get('automatic_retry') is not False or permit.get('paid_upgrade') is not False:raise ContractError('explicit one TTS/five images bounded authorization required')
  ident=permit.get('authorization_id','')
  if not isinstance(ident,str) or not re.fullmatch('[A-Za-z0-9_-]{12,100}',ident):raise ContractError('authorization id required')
  # Shared state across work directories: copying a permit must not renew the budget.
  self.dir=Path(state_root)/ident
  self.dir.mkdir(parents=True,exist_ok=False)
  (self.dir/'permit.json').write_text(json.dumps(permit,ensure_ascii=False,indent=2))
  self.count={'tts':0,'images':0};self.limits=permit['limits']
 def reserve(self,kind,request_hash):
  if kind not in self.limits or self.count[kind]>=self.limits[kind]:raise ContractError('request budget exhausted')
  index=self.count[kind]+1
  with (self.dir/(kind+'_'+str(index)+'.json')).open('x') as f:json.dump({'state':'consumed_before_post','request_sha256':request_hash},f)
  self.count[kind]=index

class Providers:
 def __init__(self,budget):self.budget=budget;self.opener=urllib.request.build_opener(NoRedirect)
 def post(self,kind,url,body,headers,maxbytes):
  self.budget.reserve(kind,hashlib.sha256(body).hexdigest())
  request=urllib.request.Request(url,data=body,headers=headers,method='POST')
  try:
   with self.opener.open(request,timeout=180) as response:
    raw=response.read(maxbytes+1);content_type=response.headers.get('Content-Type','')
   if len(raw)>maxbytes:raise ContractError('provider response too large')
   return raw,content_type
  except Exception as e:
   # Never stringify upstream exceptions: URLs/headers can carry secrets.
   raise ContractError('Provider request failed; consumed without retry ('+type(e).__name__+')') from None
 def tts(self,narration,target):
  key=os.environ.get('GEMINI_API_KEY','').strip()
  if not key:raise ContractError('Gemini credential missing')
  prompt='Türkçe, doğal ve anlaşılır erkek bilim anlatımı. Acele etme, sloganı sıkıştırma; cümle aralarında doğal nefes ver. Yalnız aşağıdaki metni aynen oku, hiçbir kelime ekleme veya çıkarma.\n\n'+narration
  if json.loads((self.budget.dir/'permit.json').read_text())['profile']=='cinematic30-v1':
   prompt='Yaklaşık yirmi yedi saniyelik sakin ve akıcı bir belgesel anlatımı, normal doğal konuşma hızı; gereksiz uzun boşluklar bırakma. '+prompt
  body=json.dumps({'contents':[{'parts':[{'text':prompt}]}],'generationConfig':{'responseModalities':['AUDIO'],'speechConfig':{'voiceConfig':{'prebuiltVoiceConfig':{'voiceName':VOICE}}}}},ensure_ascii=False).encode()
  raw,_=self.post('tts','https://generativelanguage.googleapis.com/v1beta/models/'+TTS_MODEL+':generateContent',body,{'Content-Type':'application/json','x-goog-api-key':key},12*1024*1024)
  try:
   parts=json.loads(raw)['candidates'][0]['content']['parts']
   audio=[p['inlineData'] for p in parts if 'inlineData' in p]
   if len(audio)!=1:raise ValueError()
   mime=audio[0]['mimeType']
   if not re.fullmatch(r'audio/L16;codec=pcm;rate=24000',mime,re.IGNORECASE):raise ValueError()
   pcm=base64.b64decode(audio[0]['data'],validate=True)
   if not pcm or len(pcm)%2:raise ValueError()
  except Exception:raise ContractError('Unexpected Gemini audio response; no fallback') from None
  with wave.open(str(target),'wb') as w:w.setparams((1,2,24000,0,'NONE','not compressed'));w.writeframes(pcm)
  return {'provider':'gemini','model':TTS_MODEL,'voice':VOICE,'narration_sha256':hashlib.sha256(narration.encode()).hexdigest(),'audio_sha256':hashlib.sha256(Path(target).read_bytes()).hexdigest(),'speed_factor':1.0,'attempts':1}
 def image(self,scene,target):
  account=os.environ.get('CLOUDFLARE_ACCOUNT_ID','').strip();token=os.environ.get('CLOUDFLARE_API_TOKEN','').strip()
  if not re.fullmatch('[a-fA-F0-9]{32}',account) or not token:raise ContractError('Cloudflare credentials missing/invalid')
  boundary='arena_'+uuid.uuid4().hex
  fields={'prompt':scene['prompt'],'seed':str(scene['seed']),'width':'720','height':'1280'}
  body=b''.join(('--'+boundary+'\r\nContent-Disposition: form-data; name="'+k+'"\r\n\r\n'+v+'\r\n').encode() for k,v in fields.items())+('--'+boundary+'--\r\n').encode()
  raw,ct=self.post('images','https://api.cloudflare.com/client/v4/accounts/'+account+'/ai/run/'+IMAGE_MODEL,body,{'Authorization':'Bearer '+token,'Content-Type':'multipart/form-data; boundary='+boundary},20*1024*1024)
  try:
   if 'json' in ct:
    obj=json.loads(raw)
    if obj.get('success') is False:raise ValueError()
    result=obj.get('result') or obj;encoded=result.get('image') or result.get('output')
    if encoded.startswith('data:'):encoded=encoded.split(',',1)[1]
    raw=base64.b64decode(encoded,validate=True)
   with Image.open(io.BytesIO(raw)) as im:
    im.load()
    if im.size!=(720,1280) or im.format not in ('JPEG','PNG'):raise ValueError()
   # Keep original provider bytes; suffix is informational, Pillow identifies content.
   Path(target).write_bytes(raw)
  except Exception:raise ContractError('Bad provider image; no fallback') from None
  return {'provider':'cloudflare','model':IMAGE_MODEL,'sha256':hashlib.sha256(raw).hexdigest(),'seed':scene['seed'],'attempts':1,'review':'pending'}
