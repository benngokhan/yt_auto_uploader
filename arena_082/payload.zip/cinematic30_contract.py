"""Opt-in 30s cinematic profile, separate from locked accepted071 requirements."""
import hashlib,json
from urllib.parse import urlsplit
from accepted071_contract import ContractError,digest_json,line,canonical
PROFILE='cinematic30-v1'

def validate_plan(plan):
 if plan.get('profile')!=PROFILE or plan.get('duration_seconds')!=30:raise ContractError('explicit 30s cinematic profile required')
 lines=plan.get('script_lines')
 if not isinstance(lines,list) or not 5<=len(lines)<=10:raise ContractError('bounded story lines required')
 lines=[line(x,'narration line',240) for x in lines]
 if not lines[0].endswith('?') or not lines[-1].endswith('Cevabını yoruma yaz!'):raise ContractError('opening question and spoken comment CTA required')
 if 'Merakını besle, Bilgi Dozu’nu takip et!' not in lines:raise ContractError('accepted slogan missing')
 narration='\n'.join(lines)
 if not 250<=len(narration)<=520 or plan.get('voice_speed_factor')!=1.0:raise ContractError('rewrite; never accelerate')
 source=plan.get('source') or {}
 if source.get('reviewed') is not True or not source.get('review_note'):raise ContractError('reviewed evidence required')
 urls=source.get('urls')
 if not isinstance(urls,list) or len(urls)<1 or any(urlsplit(u).scheme!='https' or not urlsplit(u).hostname for u in urls):raise ContractError('HTTPS evidence required')
 visuals=plan.get('visuals')
 if not isinstance(visuals,list) or len(visuals)!=5:raise ContractError('five distinct visuals required')
 if len({v.get('seed') for v in visuals})!=5 or len({v.get('prompt') for v in visuals})!=5:raise ContractError('distinct scenes required')
 for v in visuals:
  line(v.get('prompt'),'visual prompt',5000);line(v.get('mechanism'),'visual purpose',400)
  if type(v.get('seed')) is not int or not 0<=v['seed']<=2147483647:raise ContractError('seed')
  if v.get('representation') not in ('natural_scale','schematic') or not v.get('critical_checks'):raise ContractError('scientific visual checks required')
 return {'profile':PROFILE,'plan_sha256':digest_json(plan),'narration':narration,'script_lines':lines}
